/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package network;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.*;  

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONObject;
/**
 *
 * @author EternalBlue
 */
public class Client {
    
    public static void main(String[] args) throws IOException {
        
        var ip = "localhost";
        var port = 8080;
        Socket socket = new Socket(ip, port);
        OutputStreamWriter writer = new OutputStreamWriter(socket.getOutputStream(), "UTF-8");
        BufferedReader reader = new BufferedReader (new InputStreamReader(socket.getInputStream(), "UTF-8"));
        
        // create
        JFrame f = new JFrame();
        JLabel login = new JLabel("  Login");
        JLabel username = new JLabel("Usuario:");
        JLabel password = new JLabel("Senha:");
        JTextPane usernameBox = new JTextPane();
        JPasswordField passwordBox = new JPasswordField();
        JButton botaoCadastro = new JButton("Criar Conta");
        JButton botaoLogin = new JButton("Entrar");
        
        // style
        botaoLogin.setBounds(100, 140, 100, 40);
        botaoCadastro.setBounds(100, 190, 100, 40);
        usernameBox.setBounds(110, 55, 75, 25);  
        passwordBox.setBounds(110, 95, 75, 25);  
        login.setBounds(110, 1, 75, 75);
        username.setBounds(60, 55, 75, 25);
        password.setBounds(68, 95, 75, 25);
        login.setFont(new Font("Times New Roman",Font.BOLD,20));
        
        // existence
        f.add(botaoLogin);
        f.add(botaoCadastro);
        f.add(login);
        f.add(username);
        f.add(password);        
        f.add(usernameBox);          
        f.add(passwordBox);  
        
        botaoLogin.addActionListener((ActionListener) new ActionListener() {
            @Override
            @SuppressWarnings("empty-statement")
                    public void actionPerformed(ActionEvent e) {try {;
                        JSONObject jsonObject = new JSONObject();
                        String username = usernameBox.getText();
                        String password = passwordBox.getText();
                        jsonObject.put("protocol", "100");
                        jsonObject.put("username", username); // get interface login field
                        jsonObject.put("password", password); // get interface password field
                        writer.write(jsonObject.toString() + "\n");
                        writer.flush();
                        String line = reader.readLine();
                        jsonObject = new JSONObject(line);
                        System.out.println("[LOGIN] sent to server: " + jsonObject.toString(2));
                        
                        String loginLine = reader.readLine();
                        JSONObject loginAnswer = new JSONObject(loginLine);
                        reader.readLine();
                        System.out.println(loginAnswer);
                        if (loginAnswer.getString("protocol").equals("101")) { 
                            JOptionPane.showMessageDialog(null, "Login autorizado", "Login", 1);
                            System.out.println("Login successful");
                        }else{
                            JOptionPane.showMessageDialog(null, "Usuario ou senha incorreta", "Login", 1);
                        }
                        
                                                
                        // socket.close(); // remove -> logout

                } catch (IOException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        botaoCadastro.addActionListener((ActionListener) new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // throw new UnsupportedOperationException("Not supported yet.");
                    JSONObject jsonObject = new JSONObject();
                    var username = usernameBox.getText();
                    var password = passwordBox.getPassword();
                    jsonObject.put("protocol", "300");
                    jsonObject.put("username", username); // get interface login field
                    jsonObject.put("password", password); // get interface password field
                    writer.write(jsonObject.toString() + "\n");
                    writer.flush();
                    String line = reader.readLine();
                    jsonObject = new JSONObject(line);
                    System.out.println("[REGISTER] sent to server : " + jsonObject.toString(2));
                } catch (IOException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                    
        });
        
        f.setSize(300,300);  
        f.setLayout(null); 
        f.setVisible(true);  
    }
    
}
